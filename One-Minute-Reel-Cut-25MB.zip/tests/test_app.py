from io import BytesIO
import unittest

from app import app


class AppRouteTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_homepage_serves_editor(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"ONE-MINUTE", response.data)

    def test_health_reports_required_local_tools(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertIn("missing", response.get_json())

    def test_upload_rejects_unsupported_media_type(self):
        response = self.client.post(
            "/api/upload",
            data={"video": (BytesIO(b"not video"), "notes.txt")},
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 400)

    def test_invalid_upload_identifier_is_not_matched_as_a_glob(self):
        response = self.client.post("/api/analyze/*")
        self.assertEqual(response.status_code, 404)


if __name__ == "__main__":
    unittest.main()
