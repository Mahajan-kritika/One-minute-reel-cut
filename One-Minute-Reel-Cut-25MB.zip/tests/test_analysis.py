import unittest

from backend.analysis import build_plan, filler_events, repeated_events


class AnalysisTests(unittest.TestCase):
    def test_build_plan_keeps_ranges_around_approved_silence_only(self):
        plan = build_plan(10, [
            {"start": 2, "end": 4, "type": "silence", "label": "2s silence", "cut": True},
            {"start": 6, "end": 7, "type": "repetition", "label": "repeat", "cut": False},
        ])
        self.assertEqual([(part["start"], part["end"], part["keep"]) for part in plan], [
            (0.0, 2.0, True), (2.0, 4.0, False), (4.0, 10, True),
        ])

    def test_fillers_require_confidence_threshold(self):
        events = filler_events([
            {"start": 1, "end": 1.2, "text": "um", "probability": 0.9},
            {"start": 2, "end": 2.2, "text": "uh", "probability": 0.5},
            {"start": 3, "end": 3.2, "text": "like", "probability": 0.99},
            {"start": 4, "end": 4.2, "text": "you", "probability": 0.99},
            {"start": 4.2, "end": 4.4, "text": "know", "probability": 0.99},
        ])
        self.assertEqual(len(events), 4)
        self.assertTrue(events[0]["cut"])
        self.assertFalse(events[1]["cut"])
        self.assertFalse(events[2]["cut"])
        self.assertEqual((events[3]["start"], events[3]["end"]), (4, 4.4))

    def test_repeated_sentence_is_suggestion_not_automatic_cut(self):
        words = []
        for start, tokens in [(0, "This is the same useful sentence.".split()),
                              (3, "This is the same useful sentence.".split())]:
            words.extend({
                "start": start + i * 0.2, "end": start + (i + 1) * 0.2,
                "text": token, "probability": 0.99,
            } for i, token in enumerate(tokens))
        events = repeated_events(words)
        self.assertEqual(len(events), 1)
        self.assertFalse(events[0]["cut"])


if __name__ == "__main__":
    unittest.main()
