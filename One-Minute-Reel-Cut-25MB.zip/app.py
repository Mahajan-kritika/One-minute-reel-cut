from __future__ import annotations

import os
import re
import uuid
from pathlib import Path
from threading import Lock

from flask import Flask, jsonify, render_template, request, send_from_directory
from werkzeug.utils import secure_filename

from backend.analysis import analyze_video
from backend.media import MediaError, ffmpeg_path, ffprobe_path, probe_video
from backend.renderer import render_video

ROOT = Path(__file__).resolve().parent
UPLOAD_DIR = ROOT / "uploads"
OUTPUT_DIR = ROOT / "output"
TEMP_DIR = ROOT / "temp"
for directory in (UPLOAD_DIR, OUTPUT_DIR, TEMP_DIR):
    directory.mkdir(exist_ok=True)

MAX_UPLOAD_BYTES = 1024 * 1024 * 1024
ALLOWED_EXTENSIONS = {".mp4", ".mov", ".webm"}
jobs: dict[str, dict] = {}
jobs_lock = Lock()

app = Flask(__name__, template_folder="frontend", static_folder="frontend", static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_BYTES


def uploaded_source(upload_id: str) -> Path | None:
    if not re.fullmatch(r"[a-f0-9]{32}", upload_id):
        return None
    return next(UPLOAD_DIR.glob(f"{upload_id}.*"), None)


@app.errorhandler(413)
def request_too_large(_error):
    return jsonify(error="File exceeds the 1 GB upload limit."), 413


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/health")
def health():
    missing = []
    if not ffmpeg_path():
        missing.append("FFmpeg")
    if not ffprobe_path():
        missing.append("FFprobe")
    return jsonify(
        ready=not missing,
        missing=missing,
        message="Ready for local processing." if not missing else f"Install and add {', '.join(missing)} to PATH.",
    )


@app.post("/api/upload")
def upload():
    video = request.files.get("video")
    if not video or not video.filename:
        return jsonify(error="Choose a video to upload."), 400
    filename = secure_filename(video.filename)
    if Path(filename).suffix.lower() not in ALLOWED_EXTENSIONS:
        return jsonify(error="Supported formats are MP4, MOV, and WebM."), 400
    upload_id = uuid.uuid4().hex
    destination = UPLOAD_DIR / f"{upload_id}{Path(filename).suffix.lower()}"
    video.save(destination)
    if destination.stat().st_size == 0:
        destination.unlink(missing_ok=True)
        return jsonify(error="The uploaded file is empty."), 400
    try:
        metadata = probe_video(destination)
        if metadata["duration"] > 300:
            destination.unlink(missing_ok=True)
            return jsonify(error="Videos must be 5 minutes or shorter."), 400
        if not metadata["has_video"]:
            destination.unlink(missing_ok=True)
            return jsonify(error="The selected file does not contain a video stream."), 400
    except MediaError as exc:
        destination.unlink(missing_ok=True)
        return jsonify(error=str(exc)), 503 if "not found" in str(exc).lower() else 400
    return jsonify(
        id=upload_id,
        filename=filename,
        size=destination.stat().st_size,
        metadata=metadata,
        preview=f"/uploads/{destination.name}",
        large=destination.stat().st_size > 500 * 1024 * 1024,
    )


@app.get("/uploads/<path:filename>")
def uploaded_file(filename: str):
    return send_from_directory(UPLOAD_DIR, filename, conditional=True)


@app.post("/api/analyze/<upload_id>")
def analyze(upload_id: str):
    source = uploaded_source(upload_id)
    if source is None:
        return jsonify(error="Upload not found. Please upload the video again."), 404
    try:
        report = analyze_video(source, TEMP_DIR)
    except MediaError as exc:
        return jsonify(error=str(exc)), 503
    except Exception as exc:
        app.logger.exception("Video analysis failed")
        return jsonify(error=f"Analysis failed: {exc}"), 500
    with jobs_lock:
        jobs[upload_id] = {"status": "analyzed", "report": report}
    return jsonify(report)


@app.get("/api/jobs/<job_id>")
def job_status(job_id: str):
    with jobs_lock:
        job = jobs.get(job_id)
    if not job:
        return jsonify(error="Job not found."), 404
    return jsonify(job)


@app.post("/api/render/<upload_id>")
def render(upload_id: str):
    source = uploaded_source(upload_id)
    if source is None:
        return jsonify(error="Upload not found."), 404
    payload = request.get_json(silent=True) or {}
    try:
        report = jobs.get(upload_id, {}).get("report")
        if not report:
            return jsonify(error="Analyze the video before rendering."), 409
        result = render_video(source, report, payload, OUTPUT_DIR, TEMP_DIR)
    except MediaError as exc:
        return jsonify(error=str(exc)), 503 if "not found" in str(exc).lower() else 422
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    except Exception as exc:
        app.logger.exception("Video render failed")
        return jsonify(error=f"Rendering failed: {exc}"), 500
    return jsonify(
        filename=result.name,
        url=f"/output/{result.name}",
        metadata=probe_video(result),
    )


@app.get("/output/<path:filename>")
def output_file(filename: str):
    return send_from_directory(OUTPUT_DIR, filename, as_attachment=False, conditional=True)


@app.get("/api/download/<path:filename>")
def download(filename: str):
    if not (OUTPUT_DIR / filename).is_file():
        return jsonify(error="Export not found."), 404
    return send_from_directory(OUTPUT_DIR, filename, as_attachment=True)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
