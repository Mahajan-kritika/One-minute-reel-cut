const $ = (selector) => document.querySelector(selector);
const fileInput = $("#fileInput");
const dropzone = $("#dropzone");
let upload = null;
let report = null;
let busy = false;

const formatTime = (seconds) => {
  const total = Math.max(0, Math.round(seconds));
  return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
};
const formatSize = (bytes) => bytes > 1024 ** 3
  ? `${(bytes / 1024 ** 3).toFixed(2)} GB`
  : `${(bytes / 1024 ** 2).toFixed(1)} MB`;
const currentKeep = () => report.plan.filter((part) => part.keep);
const estimate = () => currentKeep().reduce((sum, part) => sum + part.end - part.start, 0);

async function request(url, options = {}) {
  const response = await fetch(url, options);
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || "The request could not be completed.");
  return body;
}

async function checkHealth() {
  try {
    const health = await request("/api/health");
    $("#health").textContent = health.message;
    if (!health.ready) $("#health").classList.add("error");
  } catch {
    $("#health").textContent = "Local server unavailable";
    $("#health").classList.add("error");
  }
}

async function selectFile(file) {
  if (!file) return;
  const extension = file.name.split(".").pop().toLowerCase();
  if (!["mp4", "mov", "webm"].includes(extension)) {
    alert("Choose an MP4, MOV or WebM video.");
    return;
  }
  if (file.size > 1024 ** 3) {
    alert("This file exceeds the 1 GB limit.");
    return;
  }
  if (file.size > 500 * 1024 ** 2 && !confirm("This file is larger than 500 MB and may take a long time to process. Continue?")) return;
  $("#fileInfo").classList.remove("hidden");
  $("#fileInfo").innerHTML = `<strong>${escapeHtml(file.name)}</strong> · ${formatSize(file.size)} · Checking video…`;
  $("#analyze").disabled = true;
  $("#analyze").classList.add("hidden");
  $("#analysisPanel").classList.add("hidden");
  $("#editor").classList.add("hidden");
  try {
    const form = new FormData();
    form.append("video", file);
    upload = await request("/api/upload", { method: "POST", body: form });
    const meta = upload.metadata;
    $("#fileInfo").innerHTML = `<strong>${escapeHtml(upload.filename)}</strong> · ${formatSize(upload.size)} · ${formatTime(meta.duration)} · ${meta.width}×${meta.height}`;
    $("#sourcePreview").src = upload.preview;
    $("#sourcePreview").classList.remove("hidden");
    $("#analyze").classList.remove("hidden");
    $("#analyze").disabled = false;
  } catch (error) {
    $("#fileInfo").textContent = error.message;
  }
}

function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
}

function renderPlan() {
  const timeline = $("#timeline");
  timeline.replaceChildren();
  report.plan.forEach((part, index) => {
    const row = document.createElement("div");
    row.className = `segment${part.keep ? "" : " cut"}`;
    row.innerHTML = `<span class="segment-name">${escapeHtml(part.label)}</span>
      <span class="segment-time"><input aria-label="Start time in seconds" type="number" min="0" max="${report.metadata.duration}" step="0.1" value="${part.start.toFixed(2)}">
      <input aria-label="End time in seconds" type="number" min="0" max="${report.metadata.duration}" step="0.1" value="${part.end.toFixed(2)}"></span>
      <button class="segment-status" type="button">${part.keep ? "KEEP" : "CUT"}</button>`;
    row.querySelector(".segment-status").addEventListener("click", () => {
      report.plan[index].keep = !report.plan[index].keep;
      renderPlan();
    });
    row.querySelectorAll("input").forEach((input, endpoint) => input.addEventListener("change", () => {
      const value = Number(input.value);
      if (!Number.isFinite(value) || value < 0 || value > report.metadata.duration) {
        alert("Enter a time within the source video's duration.");
        renderPlan();
        return;
      }
      report.plan[index][endpoint === 0 ? "start" : "end"] = value;
      if (report.plan[index].end <= report.plan[index].start) {
        alert("A segment end must be later than its start.");
        renderPlan();
        return;
      }
      renderPlan();
    }));
    timeline.append(row);
  });
  renderEvents();
  const seconds = estimate();
  $("#estimate").textContent = `${seconds.toFixed(1)} sec`;
  $("#limitBadge").textContent = seconds > 60.05 ? "Choose more cuts" : "60 sec max";
  $("#limitBadge").classList.toggle("over", seconds > 60.05);
  $("#render").disabled = seconds <= 0 || seconds > 60.05 || busy;
}

function renderEvents() {
  const list = $("#eventList");
  list.replaceChildren();
  report.events.forEach((event) => {
    const item = document.createElement("button");
    item.type = "button";
    item.className = `event-item${event.cut ? " approved" : ""}`;
    item.innerHTML = `<span>${escapeHtml(event.label)}</span><span>${formatTime(event.start)}–${formatTime(event.end)} · ${event.cut ? "CUT" : "KEEP"}</span>`;
    item.title = event.cut ? "Click to keep this detected segment" : "Click to approve this suggested cut";
    item.addEventListener("click", () => {
      event.cut = !event.cut;
      report.plan = buildPlanFromEvents(report);
      renderPlan();
    });
    list.append(item);
  });
}

function buildPlanFromEvents(data) {
  const cuts = data.events.filter((event) => event.cut).sort((a, b) => a.start - b.start);
  const plan = [];
  let cursor = 0;
  for (const cut of cuts) {
    const start = Math.max(cursor, cut.start);
    const end = Math.min(data.metadata.duration, cut.end);
    if (start > cursor) plan.push({ start: cursor, end: start, keep: true, label: "Keep" });
    if (end > start) plan.push({ start, end, keep: false, label: cut.label });
    cursor = Math.max(cursor, end);
  }
  if (cursor < data.metadata.duration) plan.push({ start: cursor, end: data.metadata.duration, keep: true, label: "Keep" });
  return plan;
}

async function analyze() {
  if (!upload || busy) return;
  busy = true;
  $("#analyze").disabled = true;
  $("#analyze").textContent = "Analyzing locally…";
  try {
    report = await request(`/api/analyze/${upload.id}`, { method: "POST" });
    const counts = (type) => report.events.filter((event) => event.type === type).length;
    $("#durationStat").textContent = formatTime(report.metadata.duration);
    $("#silenceStat").textContent = counts("silence");
    $("#fillerStat").textContent = counts("filler");
    $("#repeatStat").textContent = counts("repetition");
    if (report.transcript_notice) {
      $("#notice").textContent = report.transcript_notice;
      $("#notice").classList.remove("hidden");
    } else {
      $("#notice").classList.add("hidden");
    }
    if (report.crop?.notice) {
      $("#notice").textContent = [report.transcript_notice, report.crop.notice].filter(Boolean).join(" ");
      $("#notice").classList.remove("hidden");
    }
    $("#analysisPanel").classList.remove("hidden");
    $("#editor").classList.remove("hidden");
    renderPlan();
    $("#renderStatus").textContent = "Review the plan; select a segment to toggle it.";
  } catch (error) {
    alert(error.message);
  } finally {
    busy = false;
    $("#analyze").disabled = false;
    $("#analyze").textContent = "Analyze video →";
  }
}

async function render() {
  if (!report || busy) return;
  const keep = currentKeep().map(({ start, end }) => ({ start, end }));
  if (keep.length === 0) return alert("Keep at least one segment.");
  if (estimate() > 60.05) return alert("The selected segments exceed 60 seconds. Choose additional cuts.");
  busy = true;
  $("#render").disabled = true;
  $("#renderStatus").textContent = "Rendering and verifying MP4… Keep this tab open.";
  $("#result").classList.add("hidden");
  try {
    const result = await request(`/api/render/${upload.id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ keep, title: $("#titleText").value, caption_style: $("#captionStyle").value }),
    });
    $("#result").innerHTML = `<video controls playsinline src="${result.url}"></video>
      <a href="/api/download/${encodeURIComponent(result.filename)}" download>↓ Download MP4</a>
      <span class="render-status"> Verified ${formatTime(result.metadata.duration)} · ${result.metadata.width}×${result.metadata.height} · ${result.metadata.video_codec}</span>`;
    $("#result").classList.remove("hidden");
    $("#renderStatus").textContent = "Export complete. FFprobe verified the video.";
  } catch (error) {
    $("#renderStatus").textContent = error.message;
  } finally {
    busy = false;
    renderPlan();
  }
}

$("#browse").addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", (event) => selectFile(event.target.files[0]));
dropzone.addEventListener("click", (event) => { if (!event.target.closest("button")) fileInput.click(); });
dropzone.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") fileInput.click(); });
dropzone.addEventListener("dragover", (event) => { event.preventDefault(); dropzone.classList.add("dragover"); });
dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
dropzone.addEventListener("drop", (event) => { event.preventDefault(); dropzone.classList.remove("dragover"); selectFile(event.dataTransfer.files[0]); });
$("#analyze").addEventListener("click", analyze);
$("#render").addEventListener("click", render);
$("#restoreAll").addEventListener("click", () => { if (report) { report.plan.forEach((part) => { part.keep = true; }); renderPlan(); } });
checkHealth();
