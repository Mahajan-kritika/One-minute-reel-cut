# One-Minute Reel Cut

A local-first Flask app for reviewing suggested cuts and exporting a vertical MP4. Uploaded video and generated files stay on the computer running the app; the app makes no video or transcript API calls. Whisper's model files are downloaded by `faster-whisper` on the first transcription run.

## Requirements

- Python 3.10 or later (Python 3.14 may not yet have wheels for every optional ML dependency; Python 3.11 or 3.12 is the safer choice).
- FFmpeg **including FFprobe**, installed and available on `PATH`.
- `faster-whisper` for word-timed local transcription and caption generation. Its first run downloads the selected `base` model from Hugging Face.
- Internet access is needed only for initial package/model installation; videos are not uploaded.

## Windows setup

1. Install FFmpeg from a trusted distribution (for example, the Windows builds linked from [ffmpeg.org](https://ffmpeg.org/download.html)) and add the folder containing `ffmpeg.exe` and `ffprobe.exe` to your user `PATH`. Open a new PowerShell window and verify:

   ```powershell
   ffmpeg -version
   ffprobe -version
   ```

2. From this project folder, create an environment and install dependencies:

   ```powershell
   py -3.12 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

   If PowerShell blocks activation, use `.venv\Scripts\python.exe -m pip install -r requirements.txt` instead.

3. Start the server:

   ```powershell
   python app.py
   ```

   Open <http://127.0.0.1:5000>. To restrict access to this computer, leave the default host unchanged.

## Use

1. Upload an MP4, MOV, or WebM no longer than five minutes (1 GB hard limit; files over 500 MB show a warning).
2. Analyze. Silence detection uses FFmpeg; optional word timestamps, filler/repetition suggestions, and captions use the local Whisper model.
3. Review the timeline. Suggested cuts start preselected only for long silences and recognized hesitation sounds; repeated sentences are suggestions, never automatically cut. Toggle rows to keep or remove their time ranges. Restore all returns every range to the keep state.
4. Enter an optional title and render. The server refuses to render if the selected content exceeds 60 seconds. Output is H.264/AAC MP4 at 1080×1920 (center crop, not stretched), verified with FFprobe.

Exports are saved under `output\`. Original uploads and temporary audio are saved under `uploads\` and `temp\`; remove these files manually when done.

## Current limitations

- Silence ranges are detected from audio level, not semantic context. Review cuts before approval.
- Transcription is conservative but not guaranteed accurate. `faster-whisper` is optional at runtime; without it, silence detection and segment rendering remain available, but speech-based cuts/captions do not.
- OpenCV samples frames and places the crop around the median detected face position. This is a static crop, not motion tracking; fast movement can leave the face off-center. If no face is found, the crop is centered.
- Caption text uses recognized words grouped into short phrases; no animated word highlighting is rendered.
- The title is an opening overlay (three seconds), not a separate title-card clip. Detailed font, color, manual crop preview, and user-adjustable fade controls are not exposed yet.
- Render progress is reported as a final request status rather than a live percentage. Long analyses/renders keep the browser request open.
- Segment joins are direct, with short audio fades at clip edges; video transition overlaps are not added to avoid changing content timing.

All processing requires local FFmpeg. The server is intended for single-user localhost use and does not include authentication or multi-user isolation.
