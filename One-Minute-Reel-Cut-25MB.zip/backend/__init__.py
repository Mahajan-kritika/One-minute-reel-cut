"""Local video analysis and rendering components."""
