from __future__ import annotations

from pathlib import Path


def detect_crop_position(source: Path, width: int, height: int) -> dict:
    """Find a conservative static crop center from sampled faces; otherwise center."""
    try:
        import cv2
        import numpy as np
    except ImportError:
        return {"x": 0.5, "y": 0.5, "faces_found": 0, "notice": "OpenCV is unavailable; using a centered crop."}

    capture = cv2.VideoCapture(str(source))
    if not capture.isOpened():
        return {"x": 0.5, "y": 0.5, "faces_found": 0, "notice": "Face detection could not read frames; using a centered crop."}
    cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    centers = []
    duration_ms = capture.get(cv2.CAP_PROP_FRAME_COUNT) / max(capture.get(cv2.CAP_PROP_FPS), 1) * 1000
    for timestamp in range(0, int(duration_ms), 2000):
        capture.set(cv2.CAP_PROP_POS_MSEC, timestamp)
        ok, frame = capture.read()
        if not ok:
            continue
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40))
        if len(faces):
            x, y, face_width, face_height = max(faces, key=lambda face: face[2] * face[3])
            centers.append(((x + face_width / 2) / width, (y + face_height / 2) / height))
    capture.release()
    if not centers:
        return {"x": 0.5, "y": 0.5, "faces_found": 0, "notice": "No face was detected; using a centered crop."}
    return {
        "x": float(np.median([center[0] for center in centers])),
        "y": float(np.median([center[1] for center in centers])),
        "faces_found": len(centers),
        "notice": "Static face-centered crop based on sampled frames; fast subject movement may need manual review.",
    }
