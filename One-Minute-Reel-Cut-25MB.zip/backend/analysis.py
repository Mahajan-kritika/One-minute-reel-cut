from __future__ import annotations

import re
import subprocess
from difflib import SequenceMatcher
from pathlib import Path

from backend.face_detection import detect_crop_position
from backend.media import MediaError, extract_audio, require_tool

FILLERS = {"um", "uh", "umm", "uhh", "erm", "er"}


def detect_silences(source: Path, duration: float) -> list[dict]:
    command = [
        require_tool("ffmpeg"), "-i", str(source), "-af", "silencedetect=noise=-35dB:d=1.5",
        "-f", "null", "-",
    ]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=300, check=False)
    except subprocess.TimeoutExpired as exc:
        raise MediaError("Silence detection timed out.") from exc
    if result.returncode:
        detail = (result.stderr or result.stdout).strip().splitlines()
        raise MediaError(detail[-1] if detail else "FFmpeg could not analyze the audio for silence.")
    log = result.stderr
    starts = re.findall(r" silence_start: ([\d.]+)", log)
    ends = re.findall(r" silence_end: ([\d.]+)", log)
    silences = []
    for index, start in enumerate(starts):
        begin = float(start)
        end = float(ends[index]) if index < len(ends) else duration
        if end - begin >= 1.5:
            silences.append({
                "start": max(0, begin),
                "end": min(duration, end),
                "type": "silence",
                "label": f"{end - begin:.1f}s silence",
                "confidence": 0.94,
                "cut": end - begin >= 2.5 and begin > 0.4 and end < duration - 0.4,
            })
    return silences


def transcribe(audio_path: Path) -> tuple[list[dict], str | None]:
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        return [], (
            "Transcription is unavailable: install faster-whisper (see README). "
            "Silence detection and video editing still work, but captions require transcription."
        )
    try:
        model = WhisperModel("base", device="cpu", compute_type="int8")
        segments, _info = model.transcribe(
            str(audio_path), word_timestamps=True, vad_filter=True, beam_size=3
        )
        words = []
        for segment in segments:
            for word in segment.words or []:
                token = word.word.strip()
                if token:
                    words.append({
                        "start": float(word.start),
                        "end": float(word.end),
                        "text": token,
                        "probability": float(word.probability),
                    })
        if not words:
            return [], "No speech was recognized. Check that the source audio is audible."
        return words, None
    except Exception as exc:
        raise MediaError(
            f"Whisper could not load or transcribe. Ensure the model can be downloaded once, "
            f"then retry. Details: {exc}"
        ) from exc


def filler_events(words: list[dict]) -> list[dict]:
    events = []
    for index, word in enumerate(words):
        token = word["text"].lower().strip(".,!?")
        is_common_filler = token in FILLERS
        is_contextual_candidate = token == "like" or (
            token == "you" and index + 1 < len(words)
            and words[index + 1]["text"].lower().strip(".,!?") == "know"
        )
        if not (is_common_filler or is_contextual_candidate):
            continue
        last_index = index + 1 if token == "you" else index
        end = words[last_index]["end"]
        text = " ".join(item["text"] for item in words[index:last_index + 1])
        events.append({
            "start": word["start"], "type": "filler",
            "label": f"Possible filler: {text}", "text": text,
            "end": end,
            "confidence": word["probability"],
            "cut": is_common_filler and word["probability"] >= 0.75,
        })
    return events


def sentence_texts(words: list[dict]) -> list[dict]:
    sentences = []
    current = []
    for word in words:
        current.append(word)
        if re.search(r"[.!?][\"')\]]?$", word["text"]):
            sentences.append(current)
            current = []
    if current:
        sentences.append(current)
    return sentences


def repeated_events(words: list[dict]) -> list[dict]:
    sentences = sentence_texts(words)
    events = []
    seen: list[tuple[str, dict]] = []
    for sentence in sentences:
        text = " ".join(word["text"] for word in sentence)
        normalized = re.sub(r"\W+", " ", text.lower()).strip()
        if len(normalized.split()) < 4:
            continue
        for previous, original in seen:
            if SequenceMatcher(None, normalized, previous).ratio() >= 0.92:
                events.append({
                    "start": sentence[0]["start"], "end": sentence[-1]["end"],
                    "type": "repetition", "label": f"Possible repeated sentence: {text}",
                    "text": text, "confidence": 0.86, "cut": False,
                })
                break
        else:
            seen.append((normalized, sentence))
    return events


def build_plan(duration: float, events: list[dict]) -> list[dict]:
    cuts = sorted(
        (event for event in events if event["cut"]),
        key=lambda event: (event["start"], event["end"]),
    )
    merged = []
    for event in cuts:
        start = max(0.0, float(event["start"]))
        end = min(duration, float(event["end"]))
        if end <= start:
            continue
        if merged and start < merged[-1]["end"] + 0.08:
            merged[-1]["end"] = max(merged[-1]["end"], end)
            merged[-1]["reasons"].append(event["label"])
        else:
            merged.append({"start": start, "end": end, "reasons": [event["label"]]})
    plan = []
    cursor = 0.0
    for cut in merged:
        if cut["start"] > cursor:
            plan.append({"start": cursor, "end": cut["start"], "keep": True, "label": "Keep"})
        plan.append({
            "start": cut["start"], "end": cut["end"], "keep": False,
            "label": " · ".join(cut["reasons"]),
        })
        cursor = max(cursor, cut["end"])
    if cursor < duration:
        plan.append({"start": cursor, "end": duration, "keep": True, "label": "Keep"})
    return plan


def analyze_video(source: Path, temp_dir: Path) -> dict:
    from backend.media import probe_video

    metadata = probe_video(source)
    audio = temp_dir / f"{source.stem}.wav"
    words = []
    transcript_notice = None
    if metadata["has_audio"]:
        extract_audio(source, audio)
        words, transcript_notice = transcribe(audio)
    silences = detect_silences(source, metadata["duration"])
    fillers = filler_events(words)
    repetitions = repeated_events(words)
    events = sorted(silences + fillers + repetitions, key=lambda event: event["start"])
    plan = build_plan(metadata["duration"], events)
    estimated = sum(part["end"] - part["start"] for part in plan if part["keep"])
    crop = detect_crop_position(source, metadata["width"], metadata["height"])
    return {
        "metadata": metadata,
        "events": events,
        "words": words,
        "plan": plan,
        "estimated_duration": estimated,
        "transcript_notice": transcript_notice,
        "crop": crop,
    }
