from __future__ import annotations

import re
import uuid
from pathlib import Path

from backend.media import MediaError, probe_video, require_tool, run


def _time(value: object, name: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a valid time in seconds.") from exc
    if result < 0:
        raise ValueError(f"{name} cannot be negative.")
    return result


def _escape_drawtext(text: str) -> str:
    return text.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'").replace("%", "\\%")


def _make_srt(words: list[dict], keep: list[tuple[float, float]], destination: Path) -> None:
    lines = []
    output_offset = 0.0
    index = 1
    for start, end in keep:
        selected = [
            word for word in words
            if word["start"] < end and word["end"] > start and word.get("text", "").strip()
        ]
        for chunk_at in range(0, len(selected), 5):
            chunk = selected[chunk_at:chunk_at + 5]
            if not chunk:
                continue
            begin = max(chunk[0]["start"], start) - start + output_offset
            finish = min(chunk[-1]["end"], end) - start + output_offset
            if finish <= begin:
                continue
            text = " ".join(item["text"] for item in chunk)
            if chunk[-1]["text"][-1:] not in ".!?":
                text = text.rstrip(",") + ("." if chunk[-1]["text"][-1:] in ",;" else "")
            lines.extend([str(index), f"{_srt_time(begin)} --> {_srt_time(finish)}", text, ""])
            index += 1
        output_offset += end - start
    destination.write_text("\n".join(lines), encoding="utf-8")


def _srt_time(seconds: float) -> str:
    milliseconds = max(0, round(seconds * 1000))
    hours, remainder = divmod(milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds_part, millis = divmod(remainder, 1000)
    return f"{hours:02}:{minutes:02}:{seconds_part:02},{millis:03}"


def render_video(source: Path, report: dict, settings: dict, output_dir: Path, temp_dir: Path) -> Path:
    duration = float(report["metadata"]["duration"])
    raw_keep = settings.get("keep")
    if not isinstance(raw_keep, list) or not raw_keep:
        raise ValueError("Select at least one segment to keep.")
    keep = []
    for item in raw_keep:
        if not isinstance(item, dict):
            raise ValueError("The edit plan contains an invalid segment.")
        start = _time(item.get("start"), "Segment start")
        end = _time(item.get("end"), "Segment end")
        if end <= start or end > duration + 0.01:
            raise ValueError("Segment times must be increasing and within the source video.")
        keep.append((start, min(end, duration)))
    keep.sort()
    if any(keep[i][0] < keep[i - 1][1] for i in range(1, len(keep))):
        raise ValueError("Kept segments cannot overlap.")
    final_duration = sum(end - start for start, end in keep)
    if final_duration > 60.05:
        raise ValueError(
            f"Approved segments total {final_duration:.1f} seconds. Remove additional content to reach 60 seconds."
        )

    job = uuid.uuid4().hex
    caption_file = temp_dir / f"{job}.srt"
    output = output_dir / f"one-minute-reel-{job[:8]}.mp4"
    _make_srt(report.get("words", []), keep, caption_file)
    ffmpeg = require_tool("ffmpeg")
    video_filters = []
    audio_filters = []
    crop = report.get("crop", {})
    source_width = int(report["metadata"]["width"])
    source_height = int(report["metadata"]["height"])
    scale = max(1080 / source_width, 1920 / source_height)
    scaled_width = source_width * scale
    scaled_height = source_height * scale
    x_center = float(crop.get("x", 0.5)) * scaled_width
    y_center = float(crop.get("y", 0.5)) * scaled_height
    crop_x = max(0, min(scaled_width - 1080, x_center - 540))
    crop_y = max(0, min(scaled_height - 1920, y_center - 576))
    for index, (start, end) in enumerate(keep):
        video_filters.append(
            f"[0:v]trim=start={start:.4f}:end={end:.4f},setpts=PTS-STARTPTS,"
            "scale=1080:1920:force_original_aspect_ratio=increase,"
            f"crop=1080:1920:x={crop_x:.1f}:y={crop_y:.1f},"
            "setsar=1,format=yuv420p[v" + str(index) + "]"
        )
        audio_stream = "0:a" if report["metadata"]["has_audio"] else "1:a"
        audio_filters.append(
            f"[{audio_stream}]atrim=start={start:.4f}:end={end:.4f},asetpts=PTS-STARTPTS,"
            f"afade=t=in:st=0:d={min(0.08, (end-start)/2):.3f},"
            f"afade=t=out:st={max(0, end-start-0.08):.4f}:d={min(0.08, end-start):.3f}[a{index}]"
        )
    inputs = "".join(f"[v{i}][a{i}]" for i in range(len(keep)))
    video_filters.append(f"{inputs}concat=n={len(keep)}:v=1:a=1[vout][aout]")
    graph = ";".join(video_filters + audio_filters)

    title = str(settings.get("title", "")).strip()[:100]
    if title:
        title_filter = (
            f"[vout]drawtext=text='{_escape_drawtext(title)}':fontcolor=white:fontsize=54:"
            "borderw=3:bordercolor=black:box=1:boxcolor=black@0.42:boxborderw=20:"
            "x=(w-text_w)/2:y=h*0.12:enable='lt(t,3)'[vtitled]"
        )
        graph += ";" + title_filter
        video_label = "[vtitled]"
    else:
        video_label = "[vout]"

    # Subtitles filter uses an escaped absolute path, preserving spaces and drive letters on Windows.
    subtitle_path = str(caption_file.resolve()).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")
    subtitle_style = str(settings.get("caption_style", "Bold"))
    safe_margins = {"Minimal": 80, "Bold": 100, "Professional": 90}
    margin = safe_margins.get(subtitle_style, 100)
    font_size = {"Minimal": 20, "Bold": 24, "Professional": 21}.get(subtitle_style, 24)
    graph += (
        f";{video_label}subtitles=filename='{subtitle_path}':"
        f"force_style='FontName=Arial,FontSize={font_size},PrimaryColour=&H00FFFFFF,"
        f"OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=1,MarginV={margin}'[finalv]"
    )
    graph += (
        f";[aout]afade=t=in:st=0:d={min(0.15, final_duration / 2):.3f},afade=t=out:"
        f"st={max(0, final_duration - min(0.25, final_duration / 2)):.3f}:"
        f"d={min(0.25, final_duration / 2):.3f}[audiofinal]"
    )
    command = [
        ffmpeg, "-y", "-i", str(source),
    ]
    if not report["metadata"]["has_audio"]:
        command.extend([
            "-f", "lavfi", "-t", f"{duration:.4f}",
            "-i", "anullsrc=channel_layout=stereo:sample_rate=48000",
        ])
    command.extend(["-filter_complex", graph, "-map", "[finalv]", "-map", "[audiofinal]", "-c:a", "aac", "-b:a", "192k"])
    command.extend([
        "-c:v", "libx264", "-preset", "medium", "-crf", "20",
        "-movflags", "+faststart", "-t", "60", str(output),
    ])
    try:
        run(command, timeout=1800)
        verified = probe_video(output)
        if (verified["duration"] > 60.1 or verified["width"] != 1080 or verified["height"] != 1920
                or verified["video_codec"] != "h264" or verified["audio_codec"] != "aac"):
            raise MediaError("The exported MP4 did not meet the duration or vertical resolution requirements.")
    except Exception:
        output.unlink(missing_ok=True)
        raise
    finally:
        caption_file.unlink(missing_ok=True)
    return output
