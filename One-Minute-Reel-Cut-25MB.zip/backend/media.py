from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path


class MediaError(RuntimeError):
    """A media-tool or media-file error that is safe to show to the user."""


def ffmpeg_path() -> str | None:
    return shutil.which("ffmpeg")


def ffprobe_path() -> str | None:
    return shutil.which("ffprobe")


def require_tool(name: str) -> str:
    executable = shutil.which(name)
    if not executable:
        raise MediaError(f"{name} was not found. Install FFmpeg and add its bin folder to PATH.")
    return executable


def run(command: list[str], timeout: int = 900) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        raise MediaError("Media processing timed out. Try a shorter or smaller source video.") from exc
    if result.returncode:
        detail = (result.stderr or result.stdout).strip().splitlines()
        raise MediaError(detail[-1] if detail else "FFmpeg could not process this video.")
    return result


def probe_video(path: Path) -> dict:
    probe = require_tool("ffprobe")
    result = run([
        probe, "-v", "error", "-show_entries",
        "format=duration:stream=codec_type,width,height,codec_name",
        "-of", "json", str(path),
    ], timeout=60)
    try:
        data = json.loads(result.stdout)
        streams = data.get("streams", [])
        video = next((stream for stream in streams if stream.get("codec_type") == "video"), {})
        audio = next((stream for stream in streams if stream.get("codec_type") == "audio"), {})
        duration = float(data.get("format", {}).get("duration", 0))
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        raise MediaError("FFprobe could not read this video's metadata.") from exc
    if duration <= 0 or not video:
        raise MediaError("The file has no readable video stream or duration.")
    return {
        "duration": duration,
        "width": int(video.get("width", 0)),
        "height": int(video.get("height", 0)),
        "video_codec": video.get("codec_name", "unknown"),
        "audio_codec": audio.get("codec_name", "none"),
        "has_video": True,
        "has_audio": bool(audio),
    }


def extract_audio(source: Path, destination: Path) -> None:
    run([
        require_tool("ffmpeg"), "-y", "-i", str(source), "-vn", "-ac", "1",
        "-ar", "16000", "-c:a", "pcm_s16le", str(destination),
    ])
